from flask import Flask, render_template, request

app = Flask(__name__)
sentences = []
@app.route('/', methods=['GET', 'POST'])
def index():


    if request.method == 'POST':
        new_sentences = request.form.get('sentence')
        sentences.append(new_sentences)

    return render_template('index.html', sentence=sentences)

if __name__ == '__main__':
    app.run()


#이렇게하니까 리스트로 뽑혀서 출력됨