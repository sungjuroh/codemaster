from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    sentence = None

    if request.method == 'POST':        # 이 코드는 웹의 전송 버튼을 누르면 POST라는 명령어(?)가 자동으로 실행되는 것인지?   <form method="POST"> 가 index.html에 있기는 한데,,, 
        sentence = request.#form.get('sentence')  # 여기서 form 은 index.html에 있는 <form> tag를 가리키는 것인지? => <form> tag 내부의 sentence 이름의 데이터를 가져오는 것인지?

    return render_template('index.html', sentence=sentence)

if __name__ == '__main__':
    app.run()
