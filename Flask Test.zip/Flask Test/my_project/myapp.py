from flask import Flask, render_template, request, jsonify

app = Flask(__name__)
````
# Chrome storage 동작을 시뮬레이션하기 위한 가상 저장소
storage = {"texts": [], "texts2": []}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/saveText', methods=['POST'])
def save_text():
    data = request.get_json()
    text = data['text']
    key = data['key']
    list_id = data['listId']

    if text and key and list_id:
        save_text_to_storage(text, key)
        return jsonify(success=True)
    else:
        return jsonify(success=False, error='잘못된 데이터')

def save_text_to_storage(text, key):
    texts = storage.get(key, [])
    texts.append(text)
    storage[key] = texts
    # print(f"Text '{text}' saved to storage with key '{key}'")

@app.route('/loadTexts', methods=['GET'])
def load_texts():
    key = request.args.get('key')
    list_id = request.args.get('listId')

    if key and list_id:
        texts = load_texts_from_storage(key)
        return jsonify(success=True, texts=texts)
    else:
        return jsonify(success=False, error='잘못된 데이터')

def load_texts_from_storage(key):
    return storage.get(key, [])

if __name__ == '__main__':
    # app.run(debug=True)
    app.run(host='127.0.0.2', port=5002, debug=True)
